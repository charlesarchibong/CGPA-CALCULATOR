package com.zealtech.util;

public class AppConstants
{
    public static final String KEY_ANIM_TYPE = "anim_type";
    public static final String KEY_TITLE = "anim_title";
    public enum TransitionType {
        ExplodeJava
    }
}
